#!/bin/sh

##
## This script expects that run_lat.sh has been completed in two configurations:
## one with a ROB enabled and one without, using:
##
##   scripts/run_lat.sh
##   scripts/run_lat.sh ord
##

platform="SKX Xeon+FPGA"
if [ -n "${1}" ]; then
    platform="${1}_"
fi

if [ -f stats/lat_mcl1_vc1.dat ]; then
    # Multi-channel system -- assume 3 channels
    gnuplot -e "platform='${platform}'" scripts/plot_buffer_credits.gp
    gnuplot -e "platform='${platform}'; channel_name='VL0'; channel_number=1" scripts/plot_buffer_credits.gp
    gnuplot -e "platform='${platform}'; channel_name='VH0'; channel_number=2" scripts/plot_buffer_credits.gp
else
    # Assume just PCIe
    gnuplot -e "platform='${platform}'; channel_name='VH0'; channel_number=0" scripts/plot_buffer_credits.gp
fi

# Merge into a single PDF
gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile=bw-lat.pdf read_*.pdf write_*.pdf
rm read_*.pdf write_*.pdf
